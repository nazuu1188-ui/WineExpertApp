Wine Expert App — Run Package
- Raw -> OAM -> Rank -> COCO-STD -> Conclusion
- COCO-STD is treated as Similarity space in the thesis.
